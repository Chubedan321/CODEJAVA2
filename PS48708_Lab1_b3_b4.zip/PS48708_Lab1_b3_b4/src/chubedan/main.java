package chubedan;

import java.util.ArrayList;

public class main {
    public static void main(String[] args) {

        ArrayList<Employee> list = new ArrayList<>();

        list.add(new SalesEmployee("E01", "An", 5000000, 20000000, 0.1));
        list.add(new SalesEmployee("E02", "Binh", 6000000, 0, 0.08));
        list.add(new OfficeEmployee("E03", "Chi", 4000000, 20, 200000));
        list.add(new OfficeEmployee("E04", "Dung", 4500000, 22, 180000));
        list.add(new Employee("E05", "Em", 3000000));

        System.out.println("=== DANH SÁCH NHÂN VIÊN ===");
        for (Employee e : list) {
            System.out.println(e + " | Income: " + e.getIncome());
        }
        Employee max = list.get(0);
        for (Employee e : list) {
            if (e.getIncome() > max.getIncome()) {
                max = e;
            }
        }

        System.out.println("\nNhân viên thu nhập cao nhất:");
        System.out.println(max + " | Income: " + max.getIncome());

        int count = 0;
        for (Employee e : list) {
            if (e.getIncome() > 10000000) {
                count++;
            }
        }

        System.out.println("\nSố nhân viên > 10 triệu: " + count);
    }
}