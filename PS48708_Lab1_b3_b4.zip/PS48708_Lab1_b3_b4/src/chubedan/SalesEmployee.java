package chubedan;

public class SalesEmployee extends Employee {
    private double sales;
    private double commissionRate;

    public SalesEmployee(String id, String name, double baseSalary, double sales, double commissionRate) {
        super(id, name, baseSalary);
        this.sales = sales;
        this.commissionRate = commissionRate;
    }

    @Override
    public double getIncome() {
        return getBaseSalary() + sales * commissionRate;
    }
}