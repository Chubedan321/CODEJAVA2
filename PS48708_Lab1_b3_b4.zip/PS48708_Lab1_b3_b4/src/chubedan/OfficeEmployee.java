package chubedan;

public class OfficeEmployee extends Employee {
    private int workingDays;
    private double dailySalary;

    public OfficeEmployee(String id, String name, double baseSalary, int workingDays, double dailySalary) {
        super(id, name, baseSalary);
        this.workingDays = workingDays;
        this.dailySalary = dailySalary;
    }

    @Override
    public double getIncome() {
        return workingDays * dailySalary;
    }
}