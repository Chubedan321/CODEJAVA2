package chubedan;

public class Employee {
    private String id;
    private String name;
    private double baseSalary;

    public Employee(String id, String name, double baseSalary) {
        setId(id);
        this.name = name;
        setBaseSalary(baseSalary);
    }

    public void setId(String id) {
        if (id != null && !id.trim().isEmpty()) {
            this.id = id;
        } else {
            System.out.println("ID chua dung!");
        }
    }

    public void setBaseSalary(double baseSalary) {
        if (baseSalary >= 0) {
            this.baseSalary = baseSalary;
        } else {
            System.out.println("Lương chua dung!");
        }
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public double getIncome() {
        return baseSalary;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Base Salary: " + baseSalary;
    }
}